#include "split.h"
#include <stdlib.h>

char** split(const char* string, char separador){
    return NULL;
}
